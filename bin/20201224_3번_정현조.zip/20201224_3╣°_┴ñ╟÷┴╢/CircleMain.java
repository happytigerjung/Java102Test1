
public class CircleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle pizza = new Circle();
		pizza.Radius = 30;
		pizza.constant = 3.14;
		
		
		
		Circle dounut = new Circle();
		dounut.Radius = 15;
		dounut.constant = 3.14;

	}

}
